let h2 = document.querySelector("h2");
h2.addEventListener("click",function(e){
    console.log(e); 
})